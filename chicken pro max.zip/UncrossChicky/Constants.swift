//
//  Constants.swift
//  MissionUncrossableChicken
//
//  Created by Alexander Belov on 2/6/25.
//

import Foundation


class Constants {
    static var urlForValidation = "https://uncrosschicky.top/log" // https://uncrosschicky.top/log
}
// vk - https://shorturl.at/UptGb

//google - https://shorturl.at/6qHNt
